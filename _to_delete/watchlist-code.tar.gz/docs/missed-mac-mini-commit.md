---
type: correction
updated: 2026-09-07
status: current
---

# Missed Mac mini commit

The user corrected that changes made on the Mac mini were not committed after the work. This reinforces [[git-commit-workflow]]: each completed, verified, coherent change needs a focused local commit before the session moves on.

Current repo state when checked: `main` was at `f92aa9a`, with uncommitted changes under a nested `watchlist/` app directory. The nested tree looked like generated duplicate app scaffolding rather than a clean root-level Watchlist change.

Rejected: committing the nested `watchlist/` app tree without verification. It would add duplicate project files and at least one staged/modified component that had previously been staged in a broken state.

Next time: inspect `git status --short`, verify the intended working directory, run the relevant check, stage only the coherent files, and commit immediately.
